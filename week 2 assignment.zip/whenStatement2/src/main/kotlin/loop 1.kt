fun main() {
    var i = 1
    while (i < 101) {
        println(i)
        i++
    }

//    for (e in 1 until 4)  //; (4 until 10){
      //  for (e in 1 .. 10 step 2)  //; (4 until 10){

     //   println(e)
    }
