fun main() {
    var myAge = 31
    if (myAge == 30) {
        println("you are 30")

    }
        else {
            println ("you are not 30")
        }
    }

