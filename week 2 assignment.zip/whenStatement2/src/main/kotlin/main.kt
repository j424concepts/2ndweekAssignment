fun main() {
    var a = "Blue"
    when (a) {
        "Red" -> {
            println("Value is Red")
        }
        "Blue" -> {
            println("Value is Blue")
        }
        else -> {
            println("Value is Neither red nor blue")
        }
    }
}