fun main () {
    val price = 67
    if (price >= 78) {
        println("it is very expensive")
    }
    else
        if (price < 78) {
            println("it is cheap")
        }
}
