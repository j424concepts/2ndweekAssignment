fun main() {

    var x = 21
    when (x) {
        in 1..10 ->
            println("X is between 1 to 10")
        in 20..30 -> println("X is between 20 to 30")
        else -> println("X is not in the range")
    }
}
