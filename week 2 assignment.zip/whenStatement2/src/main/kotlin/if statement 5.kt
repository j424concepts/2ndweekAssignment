fun main(){
    val a = 10
    val b = 20
    val c = if(a > b ) a else b
    println(c)
    }
