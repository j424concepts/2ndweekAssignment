fun main(){
    val x = 4
    var str: String
    when (x) {
        1 -> str = "x is 1"
        2 -> str = "x is 2"
        else -> {
            str = "x value is unknown"
        }
    }
    println(str)


}