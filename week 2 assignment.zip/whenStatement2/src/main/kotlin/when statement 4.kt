fun main() {
    val animal = "dog"
    val result = when (animal) {
        "Horse" -> println("Animal is a Horse")
        "cat" -> println("Animal is a cat")
        "dog" -> println("Animal is a dog")
        else -> println("animal Not found")

    }
}