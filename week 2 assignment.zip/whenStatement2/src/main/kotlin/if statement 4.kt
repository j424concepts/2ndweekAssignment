fun main() {
    var isLoggedIn = true
    if (isLoggedIn == true) {
        println("you are logged in")
    }
    else{
        if (isLoggedIn == false) {
            println("you are not logged in")
        }
    }

}