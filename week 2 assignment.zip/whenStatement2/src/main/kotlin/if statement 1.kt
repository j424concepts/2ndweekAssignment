fun main(){
    var a = 10
    var b = 20
    var large = if (a>b) a else b
    println ("The Largest is ${large}")
}